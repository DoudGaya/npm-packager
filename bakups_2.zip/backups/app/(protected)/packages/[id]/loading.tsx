import { PageLoading } from "@/components/page-loading"

export default function PackageLoading() {
  return <PageLoading />
}
