import { PageLoading } from "@/components/page-loading"

export default function CreatePackageLoading() {
  return <PageLoading />
}
