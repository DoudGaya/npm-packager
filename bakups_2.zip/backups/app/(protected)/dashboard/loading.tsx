import { PageLoading } from "@/components/page-loading"

export default function DashboardLoading() {
  return <PageLoading />
}
